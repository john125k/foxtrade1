# foxtrade1

CLONE THE BRANCH YOU WANT TO WORK ON
fronend : for frontend
backend : for frontend

step 1: clone the repository ( git clone --single-branch --branch  "branchname" "repository url" ,
                              git remote add "name" "repository url" )

step 2: create a new branch to keep record of your work.( git checkout -b "branch name" )

step 3: make any changes and push it to your branch. ( git add "file name"
                                                      ,git commit -m "commit message"
                                                      , git push )

step 4: if the changes are working fine then it will be merged to the appropriate branch( frontend work will be merged to frontend branch and backend work will be merged to backend branch )

*to install packages :-
npm install

*to run the application :- 
npm start

server is running on port 8001
fronted is running on port 3000




